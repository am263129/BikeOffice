import React from 'react'

export default function LandingPage(){
    return(
        <div>
        </div>
    )
}