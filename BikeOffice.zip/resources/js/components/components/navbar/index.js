import React from 'react'

const NavBar = () => {
    return (
        <div className="py-5">
            <img src="/assets/images/top_image.png" className="w-full" />
        </div>
    )
}
export default NavBar